from frappe import _

def get_data():
	return [
		{
			"module_name": "Custom App",
			"type": "module",
			"label": _("Custom App")
		}
	]
